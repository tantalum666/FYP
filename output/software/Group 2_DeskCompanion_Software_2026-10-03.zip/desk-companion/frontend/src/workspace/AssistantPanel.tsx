import { useCallback, useEffect, useRef, useState } from "react";
import { Mic, MicOff, Send, Sparkles } from "lucide-react";
import { errorText, request, write } from "../api";
import type { EventInput, Translate } from "../types";
import { useWorkspace } from "./WorkspaceContext";
import { VoiceAudio } from "./audio";
import { apiOrigin } from "../native";

interface Proposal {
  id: string;
  kind: "create" | "change" | "output";
  expires_at: string;
  data: {
    event?: EventInput;
    additional_dates?: string[];
    event_id?: string;
    original?: Pick<
      EventInput,
      | "title"
      | "start_local"
      | "end_local"
      | "timezone"
      | "visibility"
      | "all_day"
    >;
    output?: { kind: string; preset: string };
    change?: { action: string; scope: string; event?: EventInput };
  };
}
interface Reply {
  mode: string;
  kind: string;
  message: string;
  proposal?: Proposal;
}

export function AssistantPanel({ t }: { t: Translate }) {
  const { data, refresh } = useWorkspace();
  const [text, setText] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState<unknown>(null);
  const [reply, setReply] = useState<Reply | null>(null),
    [proposals, setProposals] = useState<Proposal[]>([]),
    [notice, setNotice] = useState("");
  const [voiceState, setVoiceState] = useState("idle"),
    [transcript, setTranscript] = useState("");
  const audio = useRef<VoiceAudio | null>(null),
    alive = useRef(true);
  const speechText = useRef({ user: "", assistant: "" });
  const language = t("en", "zh");
  const reload = useCallback(async () => {
    try {
      const next = await request<{ proposals: Proposal[] }>(
        "/assistant/proposals",
      );
      if (alive.current) setProposals(next.proposals);
    } catch (e) {
      if (alive.current) setError(e);
    }
  }, []);
  useEffect(() => {
    alive.current = true;
    void reload();
    const timer = setInterval(() => void reload(), 2000);
    return () => {
      alive.current = false;
      clearInterval(timer);
      audio.current?.close();
    };
  }, [reload]);
  async function send(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice("");
    try {
      setReply(
        await write<Reply>("/assistant/messages", { message: text, language }),
      );
      await reload();
      setText("");
    } catch (e) {
      setError(e);
    } finally {
      setBusy(false);
    }
  }
  async function decide(id: string, action: "confirm" | "cancel") {
    setBusy(true);
    setError(null);
    try {
      const result = await write<{ queued?: boolean }>(
        `/assistant/proposals/${id}/decisions`,
        { action },
      );
      setNotice(
        result.queued
          ? t(
              "Action queued. Check the device receipt for its result.",
              "动作已排队，请在设备回执中查看结果。",
            )
          : action === "confirm"
            ? t("Saved to your calendar.", "已保存到日历。")
            : t("Draft cancelled.", "草稿已取消。"),
      );
      await reload();
      await refresh();
      window.dispatchEvent(new Event("desk:calendar"));
    } catch (e) {
      setError(e);
      await reload();
    } finally {
      setBusy(false);
    }
  }
  async function startVoice() {
    setError(null);
    setVoiceState("connecting");
    setTranscript("");
    speechText.current = { user: "", assistant: "" };
    try {
      const engine = new VoiceAudio((event) => {
        if (!alive.current) return;
        if (event.type === "ready") setVoiceState("listening");
        if (event.type === "state" && event.state) setVoiceState(event.state);
        if (event.type === "audio") setVoiceState("speaking");
        if (event.type === "turn_complete" || event.type === "interrupted")
          setVoiceState("listening");
        if (event.type === "interrupted")
          speechText.current = { user: "", assistant: "" };
        if (event.type === "transcript") {
          const role = event.role === "user" ? "user" : "assistant";
          speechText.current[role] = (
            event.final
              ? (event.text ?? "")
              : speechText.current[role] + (event.text ?? "")
          ).slice(-3000);
          setTranscript(
            (speechText.current.user
              ? t("You: ", "你：") + speechText.current.user + "\n"
              : "") +
              (speechText.current.assistant
                ? t("Companion: ", "助理：") + speechText.current.assistant
                : ""),
          );
        }
        if (event.type === "proposal" || event.type === "proposals_changed")
          void reload();
        if (event.type === "error") {
          setNotice(
            t(
              "Voice could not continue. Check the connection or provider configuration.",
              "语音未能继续，请检查连接或服务配置。",
            ),
          );
          setVoiceState("idle");
        }
        if (event.type === "closed" || event.type === "ended")
          setVoiceState("idle");
      });
      audio.current = engine;
      const url = new URL("/api/voice/ws", apiOrigin());
      url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
      await engine.start(
        async () =>
          (
            await request<{ ticket: string }>("/voice/tickets", {
              method: "POST",
              body: "{}",
            })
          ).ticket,
        language,
        url.href,
      );
    } catch (e) {
      setVoiceState("idle");
      setError(e);
      setNotice(
        t(
          "Microphone permission and a configured voice service are required.",
          "需要麦克风权限以及已配置的语音服务。",
        ),
      );
    }
  }
  return (
    <div className="workspace-panel assistant-panel">
      <div className="workspace-state">
        <Sparkles />
        <div>
          <h3>{t("A little help with your day", "帮你安排一天")}</h3>
          <p>
            {t(
              "Ask for your schedule, or prepare an event to review.",
              "查询行程，或生成日程草稿后检查保存。",
            )}
          </p>
        </div>
      </div>
      <div className="assistant-voice-row">
        <div>
          <strong>
            {voiceState === "idle"
              ? data?.voice.configured
                ? t("Voice ready to connect", "语音可连接")
                : t("Voice service not configured", "语音服务未配置")
              : t("Conversation active", "正在交谈")}
          </strong>
          <small>
            {data?.voice.configured
              ? `${data.voice.provider} · ${data.voice.model}`
              : t(
                  "Text calendar tools are available below.",
                  "下方文字日历工具可以使用。",
                )}
          </small>
        </div>
        {voiceState === "idle" ? (
          <button
            className="secondary"
            disabled={!data?.voice.configured}
            onClick={() => void startVoice()}
          >
            <Mic size={18} />
            {t("Start conversation", "开始交谈")}
          </button>
        ) : (
          <button
            className="secondary"
            onClick={() => {
              audio.current?.close();
              setVoiceState("idle");
            }}
          >
            <MicOff size={18} />
            {t("End conversation", "结束交谈")}
          </button>
        )}
      </div>
      {voiceState !== "idle" && (
        <>
          <p role="status">
            {t(
              "Speak naturally. You can interrupt; no need to hold a button.",
              "直接交谈，可以插话，不需要按住按钮。",
            )}
          </p>
          <button
            className="text-button"
            onClick={() => audio.current?.interrupt()}
          >
            {t("Stop speaking", "停止播报")}
          </button>
        </>
      )}
      {transcript && (
        <p className="assistant-reply" aria-live="polite">
          {transcript}
        </p>
      )}
      <form onSubmit={send}>
        <label className="field">
          {t("Your request", "你的要求")}
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            required
            maxLength={3000}
            rows={3}
            placeholder={t(
              "Tomorrow 15:00–16:00 Project discussion",
              "明天15:00到16:00 项目讨论",
            )}
          />
        </label>
        <div className="workspace-inline-actions">
          <button className="primary" disabled={busy || !text.trim()}>
            <Send size={16} />
            {t("Send", "发送")}
          </button>
          <button
            type="button"
            className="text-button"
            onClick={() => setText(t("What is on today?", "今天的行程"))}
          >
            {t("Today’s briefing", "今日简报")}
          </button>
        </div>
      </form>
      <p className="workspace-hint">
        {t(
          "Local text mode uses date rules. It asks for exact times instead of guessing. AI voice is a separate connection.",
          "本地文字模式使用日期规则，需要明确时间；AI语音单独连接。",
        )}
      </p>
      {reply && (
        <p className="assistant-reply" role="status">
          {reply.message}
        </p>
      )}
      {proposals.map((p) => {
        const event = p.data.event ?? p.data.change?.event;
        return (
          <article className="assistant-proposal" key={p.id}>
            <span className="workspace-eyebrow">
              {t("Review before saving", "保存前检查")}
            </span>
            <h3>
              {event?.title ?? t("Change calendar event", "修改日历事项")}
            </h3>
            {event ? (
              <>
                <p>
                  {event.start_local.slice(0, 16).replace("T", " ")} →{" "}
                  {event.end_local.slice(0, 16).replace("T", " ")}
                </p>
                <small>
                  {event.timezone} ·{" "}
                  {event.visibility === "private"
                    ? t("Private", "私人")
                    : t("Displayable", "可展示")}
                </small>
                {p.data.additional_dates?.length ? (
                  <p>
                    {t("Also on: ", "同时添加：")}
                    {p.data.additional_dates.join(", ")}
                  </p>
                ) : null}
                {event.recurrence.frequency !== "none" && (
                  <p>
                    {t("Repeats: ", "重复：")}
                    {event.recurrence.frequency}
                  </p>
                )}
              </>
            ) : (
              <>
                {p.data.original && (
                  <>
                    <strong>
                      {p.data.original.title || t("Private event", "私人事项")}
                    </strong>
                    <p>
                      {p.data.original.start_local.replace("T", " ")} →{" "}
                      {p.data.original.end_local.replace("T", " ")} ·{" "}
                      {p.data.original.timezone}
                    </p>
                  </>
                )}
                {p.data.output && (
                  <p>
                    {p.data.output.kind === "arm"
                      ? t("Arm", "机械臂")
                      : t("Light", "灯光")}{" "}
                    · {p.data.output.preset}
                  </p>
                )}
                <p>
                  {p.data.change?.action === "delete"
                    ? t("Delete", "删除")
                    : p.data.change?.action === "complete"
                      ? t("Mark complete", "标记完成")
                      : p.data.change?.action === "reopen"
                        ? t("Mark incomplete", "取消完成")
                        : p.data.change
                          ? t("Update", "更新")
                          : t("Named preset only", "仅执行预设动作")}
                  {p.data.change &&
                    (p.data.change.scope === "series"
                      ? t(" · Entire series", " · 整个系列")
                      : t(" · This occurrence", " · 仅本次"))}
                </p>
              </>
            )}
            <small>
              {t("Expires at ", "有效至 ")}
              {new Date(p.expires_at).toLocaleTimeString(
                language === "zh" ? "zh-CN" : "en-GB",
                { hour: "2-digit", minute: "2-digit" },
              )}
            </small>
            <div className="workspace-inline-actions">
              <button
                className="primary"
                disabled={busy}
                onClick={() => void decide(p.id, "confirm")}
              >
                {t("Confirm & save", "确认并保存")}
              </button>
              <button
                className="secondary"
                disabled={busy}
                onClick={() => void decide(p.id, "cancel")}
              >
                {t("Cancel draft", "取消草稿")}
              </button>
            </div>
          </article>
        );
      })}
      {notice && <p role="status">{notice}</p>}
      {!!error && (
        <p className="error-message" role="alert">
          {errorText(error, t)}
        </p>
      )}
    </div>
  );
}
