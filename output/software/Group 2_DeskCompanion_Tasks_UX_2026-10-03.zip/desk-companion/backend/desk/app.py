import asyncio
import contextlib
import os
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from datetime import date, datetime
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import Depends, FastAPI, Header, Request, Response, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, FileResponse
from starlette.middleware.trustedhost import TrustedHostMiddleware
from starlette.middleware.cors import CORSMiddleware

from .access import DEVICE_COOKIE
from .assistant_routes import assistant_routes
from .device_routes import device_routes
from .runtime import Runtime
from .workspace_data import PreferencesUpdate
from .voice import voice_routes
from .exchange_routes import exchange_routes
from .google_calendar import google_routes
from .phone import phone_snapshot
from .tasks import task_routes

from .schemas import CreateEvents, EventAction, Login, ReminderAction, SettingsInput
from .store import DomainError, Store


COOKIE = "desk_companion_session"


def create_app(directory=None, clock=None, password=None, scheduler=True, allow_replay=None):
    runtime = (
        directory
        or os.environ.get("DESK_RUNTIME_DIR")
        or Path(__file__).resolve().parents[2] / ".runtime"
    )
    store = Store(runtime, clock=clock, password=password)
    services = Runtime(
        store,
        allow_replay=os.environ.get("DESK_ALLOW_REPLAY") == "1"
        if allow_replay is None
        else allow_replay,
    )
    attempts = defaultdict(deque)

    @asynccontextmanager
    async def lifespan(app):
        async def worker():
            while True:
                await asyncio.to_thread(services.tick)
                await asyncio.sleep(1)

        task = asyncio.create_task(worker()) if scheduler else None

        async def public_data_worker():
            while True:
                await asyncio.to_thread(services.data.poll_weather)
                await asyncio.sleep(10)

        data_task = asyncio.create_task(public_data_worker()) if scheduler else None

        async def task_advice_worker():
            while True:
                await asyncio.to_thread(services.text_ai.enrich_one)
                await asyncio.sleep(30)

        advice_task = asyncio.create_task(task_advice_worker()) if scheduler else None
        yield
        for running in (task, data_task, advice_task):
            if not running:
                continue
            running.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await running

    app = FastAPI(title="Desk Companion", version="0.1.0", lifespan=lifespan)
    app.state.store = store
    app.state.runtime = services
    public_origin = os.environ.get("DESK_PUBLIC_ORIGIN", "").rstrip("/")
    allowed_origins = {
        f"http://{host}{port}"
        for host in ("localhost", "127.0.0.1", "testserver")
        for port in ("", ":5190", ":8831", ":5191", ":8832")
    }
    allowed_hosts = ["localhost", "127.0.0.1", "testserver"]
    if public_origin:
        parts = urlsplit(public_origin)
        if (
            parts.scheme != "https"
            or not parts.hostname
            or parts.path
            or parts.query
            or parts.fragment
            or parts.username
        ):
            raise ValueError("DESK_PUBLIC_ORIGIN must be a single HTTPS origin")
        allowed_origins.add(public_origin)
        allowed_hosts.append(parts.hostname)
    if os.environ.get("DESK_NATIVE_CLIENTS") == "1":
        allowed_origins.add("capacitor://localhost")
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["capacitor://localhost"],
            allow_credentials=True,
            allow_methods=["GET", "POST", "DELETE"],
            allow_headers=[
                "Authorization",
                "Content-Type",
                "X-Desk-Request",
                "X-Operation-Id",
                "X-Desk-Native",
            ],
        )
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=allowed_hosts)

    @app.middleware("http")
    async def local_request_boundary(request, call_next):
        origin = request.headers.get("origin")
        if origin:
            if origin not in allowed_origins:
                return JSONResponse({"error": {"code": "ORIGIN_NOT_ALLOWED"}}, status_code=403)
        if request.method not in {"GET", "HEAD", "OPTIONS"} and request.url.path.startswith(
            "/api/"
        ):
            if request.headers.get("x-desk-request") != "1":
                return JSONResponse({"error": {"code": "REQUEST_HEADER_REQUIRED"}}, status_code=403)
        response = await call_next(request)
        response.headers["Cache-Control"] = (
            "public, max-age=31536000, immutable"
            if request.url.path.startswith("/assets/") and response.status_code == 200
            else "no-store"
        )
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(self), geolocation=()"
        return response

    @app.exception_handler(DomainError)
    async def domain_error(request, error):
        return JSONResponse({"error": {"code": error.code}}, status_code=error.status)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request, error):
        fields = [".".join(str(v) for v in e["loc"][1:]) for e in error.errors()]
        return JSONResponse(
            {"error": {"code": "VALIDATION_FAILED", "fields": fields}}, status_code=422
        )

    def authenticated(request: Request):
        bearer = request.headers.get("Authorization", "").removeprefix("Bearer ")
        principal = services.access.principal(
            request.cookies.get(COOKIE), request.cookies.get(DEVICE_COOKIE), bearer
        )
        if not principal:
            raise DomainError("AUTH_REQUIRED", 401)
        return principal

    def owner(request: Request):
        if not store.session_valid(request.cookies.get(COOKIE)):
            raise DomainError("OWNER_SIGN_IN_REQUIRED", 403)
        return {"kind": "owner", "id": "owner", "name": "Owner"}

    def agent(request: Request):
        token = request.headers.get("Authorization", "").removeprefix("Bearer ")
        if not services.access.agent_valid(token):
            raise DomainError("AGENT_AUTH_REQUIRED", 401)

    def limit(bucket, request, count, seconds):
        identity = (bucket, request.client.host if request.client else "local")
        queue = attempts[identity]
        now = time.monotonic()
        while queue and queue[0] < now - seconds:
            queue.popleft()
        if len(queue) >= count:
            raise DomainError("TRY_LATER", 429)
        queue.append(now)

    def operation_id(x_operation_id: str = Header(default="")):
        return x_operation_id

    @app.get("/api/health")
    def health():
        return {"service": "desk-companion", "status": "ok"}

    @app.post("/api/session")
    def login(payload: Login, request: Request, response: Response):
        ip = request.client.host if request.client else "local"
        queue = attempts[ip]
        now = time.monotonic()
        while queue and queue[0] < now - 60:
            queue.popleft()
        if len(queue) >= 10:
            raise DomainError("TRY_LATER", 429)
        queue.append(now)
        token = store.authenticate(payload.username, payload.password)
        queue.clear()
        response.set_cookie(
            COOKIE,
            token,
            httponly=True,
            samesite="strict",
            secure=request.url.scheme == "https",
            max_age=8 * 3600,
            path="/api",
        )
        return {"username": "owner"}

    @app.get("/api/session", dependencies=[Depends(authenticated)])
    def session(request: Request, response: Response, principal=Depends(authenticated)):
        if token := request.cookies.get(DEVICE_COOKIE):
            if services.access.principal(device_token=token):
                response.set_cookie(
                    DEVICE_COOKIE,
                    token,
                    httponly=True,
                    samesite="strict",
                    secure=request.url.scheme == "https",
                    max_age=365 * 86400,
                    path="/api",
                )
        with store.connection() as conn:
            return {"username": "owner", "settings": store.settings(conn), "principal": principal}

    @app.delete("/api/session", dependencies=[Depends(authenticated)])
    def logout(request: Request, response: Response, principal=Depends(authenticated)):
        device_principal = services.access.principal(
            device_token=request.cookies.get(DEVICE_COOKIE),
            bearer=request.headers.get("Authorization", "").removeprefix("Bearer "),
        )
        if request.cookies.get(COOKIE):
            store.logout(request.cookies[COOKIE])
        if device_principal or principal["kind"] != "owner":
            from uuid import uuid4

            services.access.revoke((device_principal or principal)["id"], uuid4().hex)
        response.delete_cookie(COOKIE, path="/api")
        response.delete_cookie(DEVICE_COOKIE, path="/api")
        return {"signed_out": True}

    @app.get("/api/revision", dependencies=[Depends(authenticated)])
    def revision():
        return {"revision": store.revision()}

    @app.get("/api/phone/snapshot", dependencies=[Depends(authenticated)])
    def phone():
        return phone_snapshot(services)

    @app.get("/api/calendar", dependencies=[Depends(authenticated)])
    def calendar(start: datetime, end: datetime, display: bool = False):
        snapshot = store.snapshot(start, end)
        posture = services.posture.snapshot()
        hide_when_away = (
            display
            and posture["preferences"]["enabled"]
            and posture["preferences"]["privacy_when_away"]
            and (not posture["connected"] or posture["status"] in {"absent", "unknown", "paused"})
        )
        if hide_when_away:
            from .calendar import redact

            snapshot["occurrences"] = [redact(o, True) for o in snapshot["occurrences"]]
            with store.connection() as conn:
                snapshot["reminders"] = store.reminder_list(conn, {"hide_private": True})
        snapshot["automatic_privacy"] = bool(hide_when_away)
        snapshot["device"] = services.device_status()
        return snapshot

    @app.post("/api/events", dependencies=[Depends(authenticated)])
    def create_events(payload: CreateEvents, key=Depends(operation_id)):
        return store.create(payload, key)

    @app.get("/api/events/{event_id}", dependencies=[Depends(authenticated)])
    def read_event(event_id: str):
        with store.connection() as conn:
            return store.event(conn, event_id)

    @app.post("/api/events/{event_id}/actions", dependencies=[Depends(authenticated)])
    def event_action(event_id: str, payload: EventAction, key=Depends(operation_id)):
        return store.event_action(event_id, payload, key)

    @app.post("/api/reminders/{reminder_id}/actions", dependencies=[Depends(authenticated)])
    def reminder_action(reminder_id: str, payload: ReminderAction, key=Depends(operation_id)):
        return store.reminder_action(reminder_id, payload, key)

    @app.post("/api/settings", dependencies=[Depends(authenticated)])
    def settings(payload: SettingsInput, key=Depends(operation_id)):
        return store.update_settings(payload, key)

    @app.get("/api/records", dependencies=[Depends(authenticated)])
    def records(
        kind: str = "all", source: str = "all", start: date | None = None, end: date | None = None
    ):
        return {
            "records": services.data.record_rows(
                kind, source, str(start) if start else None, str(end) if end else None
            )
        }

    @app.get("/api/records.csv", dependencies=[Depends(authenticated)])
    def records_csv(
        kind: str = "all", source: str = "all", start: date | None = None, end: date | None = None
    ):
        return Response(
            services.data.records_csv(
                kind=kind,
                source=source,
                start=str(start) if start else None,
                end=str(end) if end else None,
            ),
            media_type="text/csv",
            headers={"Content-Disposition": 'attachment; filename="desk-records.csv"'},
        )

    @app.post("/api/workspace/preferences", dependencies=[Depends(authenticated)])
    def workspace_preferences(payload: PreferencesUpdate, key=Depends(operation_id)):
        return services.data.update(payload, key)

    @app.post("/api/announcements/claim", dependencies=[Depends(authenticated)])
    def announcement(payload: dict):
        return services.data.claim_announcement(
            str(payload.get("client_id", "")),
            services.posture.snapshot(),
            services.tasks.listing(display=True)["tasks"],
        )

    app.include_router(device_routes(services, authenticated, owner, agent, operation_id, limit))
    app.include_router(task_routes(services, authenticated, operation_id))
    app.include_router(assistant_routes(services, authenticated, operation_id))
    app.include_router(voice_routes(services, authenticated, agent, allowed_origins, limit))
    app.include_router(exchange_routes(services, authenticated, owner, operation_id))
    app.include_router(google_routes(services, owner, operation_id))
    static_root = Path(__file__).resolve().parents[2] / "frontend" / "dist"

    @app.get("/{path:path}", include_in_schema=False)
    def static(path: str):
        if (
            path == "api"
            or path.startswith("api/")
            or any(part.startswith(".") for part in Path(path).parts)
        ):
            raise HTTPException(404)
        candidate = (static_root / path).resolve()
        if not candidate.is_relative_to(static_root.resolve()):
            raise HTTPException(404)
        if not candidate.is_file():
            if Path(path).suffix:
                raise HTTPException(404)
            candidate = static_root / "index.html"
        if not candidate.is_file():
            raise HTTPException(
                503, "Frontend not built. Run npm ci and npm run build in frontend/."
            )
        return FileResponse(
            candidate,
            headers={
                "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; font-src 'self'; img-src 'self' data: blob:; connect-src 'self'; worker-src 'self'; media-src 'self' blob:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
            },
        )

    return app
