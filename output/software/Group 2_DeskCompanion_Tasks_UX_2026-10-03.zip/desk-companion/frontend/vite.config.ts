import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api": {
        target: process.env.DESK_API_TARGET || "http://127.0.0.1:8831",
        ws: true,
      },
    },
  },
  build: { target: ["es2022", "safari17"] },
});
